// [주의] 붙여넣기 하는 과정에서 export 키워드를 삭제하지 않도록 주의하세요!
export const firebaseConfig = {
  apiKey: "",
  authDomain: "",
  databaseURL: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: "",
  measurementId: ""
};
